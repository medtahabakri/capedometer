export interface PedometerPlugin {
  echo(options: { value: string }): Promise<{ value: string }>;
  queryData(options: {
    startDate: string,
    endDate: string
  }): Promise<{ value: number }>
  isStepCountingAvailable(): Promise<{ value: boolean }>
}
