package com.medtahabakri.plugins.capedometer;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "Pedometer")
public class PedometerPlugin extends Plugin {

    private Pedometer implementation = new Pedometer();

    @PluginMethod
    public void echo(PluginCall call) {
        String value = call.getString("value");

        JSObject ret = new JSObject();
        ret.put("value", implementation.echo(value));
        call.resolve(ret);
    }

    @PluginMethod
    public void queryData(PluginCall call) {
        
        String start = call.getString("startDate");
        String end = call.getString("endDate");

        JSObject ret = new JSObject();
        ret.put("value", implementation.echo(start,end));
        call.resolve(ret);
    }

    
    @Override
    @PluginMethod
    public void checkPermissions(PluginCall call) {
        if (implementation.isPedometerEnabled()) {
            super.checkPermissions(call);
        } else {
            call.reject("Location services are not enabled");
        }
    }

    @Override
    @PluginMethod
    public void requestPermissions(PluginCall call) {
        if (implementation.isPedometerEnabled()) {
            super.requestPermissions(call);
        } else {
            call.reject("Location services are not enabled");
        }
    }

}
