package com.medtahabakri.plugins.capedometer;

import android.util.Log;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class Pedometer {
    public static int STOPPED = 0;
    public static int STARTING = 1;
    public static int RUNNING = 2;
    public static int ERROR_FAILED_TO_START = 3;
    public static int ERROR_NO_SENSOR_FOUND = 4;

    private int status;     // status of listener
    private float startsteps; //first value, to be substracted
    private long starttimestamp; //time stamp of when the measurement starts

    private SensorManager sensormanager; // Sensor manager
    private Sensor mSensor;             // Pedometer sensor returned by sensor manager

    private Context context;

    public String echo(String value) {
        Log.i("Echo", value);
        return value;
    }

    public Int queryData(String start,String end) {

        sensormanager = (SensorManager) getSystemService()

        Log.i("Echo", value);
        return value;
    }
}
